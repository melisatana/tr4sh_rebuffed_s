//Originally Knuckles Code
#![allow(unused_macros)]
use {
	skyline::hooks::{
		InlineCtx,
		Region,
		getRegionAddress
    },
    smash::{
        app::{
			lua_bind::*,
			utility::*,
			*
		},
		hash40,
        lib::{
			L2CAgent,
			lua_const::*,
		},
		lua2cpp::L2CFighterCommon,
        phx::*,
    },
	smashline::*,
};

//use super::*;
//use smash2;

//BomaExt, helps with various things
pub trait BomaExt {
    unsafe fn is_fighter(&mut self) -> bool;
    unsafe fn is_status_one_of(&mut self, kinds: &[i32]) -> bool;
    unsafe fn is_weapon(&mut self) -> bool;
    unsafe fn kind(&mut self) -> i32;
}

impl BomaExt for BattleObjectModuleAccessor {
    unsafe fn is_fighter(&mut self) -> bool {
        return smash::app::utility::get_category(self) == *BATTLE_OBJECT_CATEGORY_FIGHTER;
    }
    unsafe fn is_status_one_of(&mut self, kinds: &[i32]) -> bool {
        let kind = StatusModule::status_kind(self);
        return kinds.contains(&kind);
    }
    unsafe fn is_weapon(&mut self) -> bool {
        return smash::app::utility::get_category(self) == *BATTLE_OBJECT_CATEGORY_WEAPON;
    }
    unsafe fn kind(&mut self) -> i32 {
        return smash::app::utility::get_kind(self);
    }
}

pub static mut FLOAT_OFFSET: usize = 0x4E53C0;

pub static FLOAT_SEARCH_CODE: &[u8] = &[
    0x00, 0x1c, 0x40, 0xf9, 0x08, 0x00, 0x40, 0xf9, 0x03, 0x19, 0x40, 0xf9,
];

pub static mut INT_OFFSET : usize = 0x4E53E0;

//pub static mut INT_OFFSET: usize = 0x4DED80;

pub static INT_SEARCH_CODE: &[u8] = &[
    0x00, 0x1c, 0x40, 0xf9, 0x08, 0x00, 0x40, 0xf9, 0x03, 0x11, 0x40, 0xf9,
];




//Related to Param Edits
fn find_subsequence(haystack: &[u8], needle: &[u8]) -> Option<usize> {
    haystack.windows(needle.len()).position(|window| window == needle)
}

//Related to Param Edits
#[skyline::hook(offset=0x3f0028, inline)]
pub unsafe fn offset_dump(ctx: &InlineCtx) {
	let text = skyline::hooks::getRegionAddress(skyline::hooks::Region::Text) as u64;
	//println!("Function Offset: {:#X}", ctx.registers[8].x.as_ref() - text);
}

//Param Adjustments
#[skyline::hook(offset=FLOAT_OFFSET)]
pub unsafe fn get_param_float_replace(module_accessor: u64, param_type: u64, param_hash: u64) -> f32 {
	let mut boma = *((module_accessor as *mut u64).offset(1)) as *mut BattleObjectModuleAccessor;
	let boma_reference = &mut *boma;
	let fighter_kind = boma_reference.kind();
	let entry_id = WorkModule::get_int(boma, *FIGHTER_INSTANCE_WORK_ID_INT_ENTRY_ID) as usize;
	if boma_reference.is_fighter() {
		if fighter_kind == *FIGHTER_KIND_PIKACHU {
			if param_type == hash40("dash_speed") {
				if crate::pikachu::PIKACHU_DOWNB_STATIC_IS_HIT[entry_id] {
					return 2.5;
				}
			}
			if param_type == hash40("run_speed_max") {
				if crate::pikachu::PIKACHU_DOWNB_STATIC_IS_HIT[entry_id] {
					return 2.4;
				}
			}
			if param_type == hash40("air_speed_x_stable") {
				if crate::pikachu::PIKACHU_DOWNB_STATIC_IS_HIT[entry_id] {
					return 1.21;
				}
			}
			if param_type == hash40("weight") {
				if crate::pikachu::PIKACHU_DOWNB_STATIC_IS_HIT[entry_id] {
					return 95.0;
				}
			}
		}
		if fighter_kind == *FIGHTER_KIND_KIRBY {
			if param_type == hash40("dash_speed") {
				if crate::sonic::SKIRBY_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 1 {
					return 2.1;
				}
				if crate::sonic::SKIRBY_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 2 {
					return 2.15;
				}
				if crate::sonic::SKIRBY_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 3 {
					return 2.2;
				}
				if crate::sonic::SKIRBY_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 4 {
					return 2.3;
				}
			}
			if param_type == hash40("run_speed_max") {
				if crate::sonic::SKIRBY_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 1 {
					return 2.0;
				}
				if crate::sonic::SKIRBY_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 2 {
					return 2.2;
				}
				if crate::sonic::SKIRBY_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 3 {
					return 2.4;
				}
				if crate::sonic::SKIRBY_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 4 {
					return 2.8;
				}
			}
			if param_type == hash40("run_accel_mul") {
				if crate::sonic::SKIRBY_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 1 {
					return 0.111;
				}
				if crate::sonic::SKIRBY_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 2 {
					return 0.12;
				}
				if crate::sonic::SKIRBY_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 3 {
					return 0.128;
				}
				if crate::sonic::SKIRBY_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 4 {
					return 0.13;
				}
			}
			if param_type == hash40("walk_speed_max") {
				if crate::sonic::SKIRBY_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 1 {
					return 1.0;
				}
				if crate::sonic::SKIRBY_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 2 {
					return 1.15;
				}
				if crate::sonic::SKIRBY_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 3 {
					return 1.25;
				}
				if crate::sonic::SKIRBY_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 4 {
					return 1.35;
				}
			}
			if param_type == hash40("air_speed_x_stable") {
				if crate::sonic::SKIRBY_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 1 {
					return 1.08;
				}
				if crate::sonic::SKIRBY_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 2 {
					return 1.11;
				}
				if crate::sonic::SKIRBY_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 3 {
					return 1.14;
				}
				if crate::sonic::SKIRBY_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 4 {
					return 1.2;
				}
			}
			if param_type == hash40("param_shadowball") {
				if param_hash == hash40("angle") {
					if crate::mewtwo::MEWTWO_NEUTRALB_DOWN_ANGLE[entry_id] {
						return -40.0;
					}
					if crate::mewtwo::MEWTWO_NEUTRALB_UP_ANGLE[entry_id] {
						return 40.0;
					}
				}
			}
			if param_type == hash40("param_special_n") {
				if param_hash == hash40("special_n_fail_rot") {
					if crate::sonic::SONIC_NEUTRALB_BOUNCE[entry_id] {
						return -90.0;
					}
				}
			}
			if param_type == hash40("param_special_n") {
				if param_hash == hash40("n1_start_speed_x") {
					if crate::miifighter::MIIFIGHTER_IRONBALL_OOPS[entry_id] {
						return -2.45;
					}
				}
			}
		}
		if fighter_kind == *FIGHTER_KIND_LUIGI {
			if param_type == hash40("dive_speed_y") {
				if crate::luigi::LUIGI_UPB_SUPERFAST_FALL[entry_id] {
					return 4.5;
				}
			}
		}
		if fighter_kind == *FIGHTER_KIND_GAMEWATCH {
			if param_type == hash40("landing_attack_air_frame_lw") {
				if crate::gamewatch::GAMEWATCH_SLOW_FAIR[entry_id] {
					return 17.0;
				}
			}
		}
		if fighter_kind == *FIGHTER_KIND_SZEROSUIT {
			if param_type == hash40("param_special_n") {
				if param_hash == hash40("charge_speed") {
					if crate::szerosuit::SZEROSUIT_PASSIVE_TIMER_READY[entry_id] {
						return 10.0;
					}
				}
			}
		}
		if fighter_kind == *FIGHTER_KIND_PZENIGAME {
			if param_type == hash40("dash_speed") {
				if crate::pzenigame::SQUIRTLE_TORRENT[entry_id] {
					return 2.5;
				}
			}
			if param_type == hash40("run_speed_max") {
				if crate::pzenigame::SQUIRTLE_TORRENT[entry_id] {
					return 2.4;
				}
			}
			if param_type == hash40("param_special_hi") {
				if param_hash == hash40("pass_mul") {
					if WorkModule::get_int(boma, *FIGHTER_PZENIGAME_INSTANCE_WORK_ID_INT_SPECIAL_N_CHARGE) == 75 {
						return 1.25;
					}
				}
				if param_hash == hash40("air_pass_mul") {
					if WorkModule::get_int(boma, *FIGHTER_PZENIGAME_INSTANCE_WORK_ID_INT_SPECIAL_N_CHARGE) == 75 {
						return 1.5;
					}
				}
			}
		}
		if fighter_kind == *FIGHTER_KIND_SONIC {
			if param_type == hash40("run_speed_max") {
				if crate::sonic::SONIC_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 1 {
					return 3.4;
				}
				if crate::sonic::SONIC_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 2 {
					return 3.5;
				}
				if crate::sonic::SONIC_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 3 {
					return 3.6;
				}
				if crate::sonic::SONIC_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 4 {
					return 3.8;
				}
			}
			if param_type == hash40("walk_speed_max") {
				if crate::sonic::SONIC_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 1 {
					return 1.5;
				}
				if crate::sonic::SONIC_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 2 {
					return 1.55;
				}
				if crate::sonic::SONIC_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 3 {
					return 1.65;
				}
				if crate::sonic::SONIC_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 4 {
					return 1.8;
				}
			}
			if param_type == hash40("run_accel_mul") {
				if crate::sonic::SONIC_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 1 {
					return 0.17;
				}
				if crate::sonic::SONIC_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 2 {
					return 0.18;
				}
				if crate::sonic::SONIC_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 3 {
					return 0.2;
				}
				if crate::sonic::SONIC_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 4 {
					return 0.22;
				}
			}
			if param_type == hash40("dash_speed") {
				if crate::sonic::SONIC_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 1 {
					return 2.5;
				}
				if crate::sonic::SONIC_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 2 {
					return 2.6;
				}
				if crate::sonic::SONIC_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 3 {
					return 2.7;
				}
				if crate::sonic::SONIC_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 4 {
					return 2.8;
				}
			}
			if param_type == hash40("air_speed_x_stable") {
				if crate::sonic::SONIC_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 1 {
					return 1.24;
				}
				if crate::sonic::SONIC_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 2 {
					return 1.26;
				}
				if crate::sonic::SONIC_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 3 {
					return 1.28;
				}
				if crate::sonic::SONIC_NEUTRALB_CURRENT_SPEEDUP_LEVEL[entry_id] == 4 {
					return 1.31;
				}
			}
			if param_type == hash40("param_special_n") {
				if param_hash == hash40("special_n_fail_rot") {
					if crate::sonic::SONIC_NEUTRALB_BOUNCE[entry_id] {
						return -90.0;
					}
				}
			}
		}
		if fighter_kind == *FIGHTER_KIND_MIIFIGHTER {
			if param_type == hash40("param_special_n") {
				if param_hash == hash40("n1_start_speed_x") {
					if crate::miifighter::MIIFIGHTER_IRONBALL_OOPS[entry_id] {
						return -2.45;
					}
				}
			}
		}
		if fighter_kind == *FIGHTER_KIND_KAMUI {
			if param_type == hash40("landing_attack_air_frame_lw") {
				if crate::kamui::CORRIN_SLOW_DOWN_AIR[entry_id] {
					return 34.0;
				}
			}
    	}
		if fighter_kind == *FIGHTER_KIND_GAOGAEN {
			if param_type == hash40("param_special_n") {
				if param_hash == hash40("special_n_speed_x_max") {
					if crate::gaogaen::GAOGAEN_REVENGE_CURRENT_POWER_LEVEL[entry_id] == 5 {
						return 1.6;
					}
					if crate::gaogaen::GAOGAEN_REVENGE_CURRENT_POWER_LEVEL[entry_id] == 4 {
						return 1.4;
					}
					if crate::gaogaen::GAOGAEN_REVENGE_CURRENT_POWER_LEVEL[entry_id] == 3 {
						return 1.2;
					}
					if crate::gaogaen::GAOGAEN_REVENGE_CURRENT_POWER_LEVEL[entry_id] == 2 {
						return 1.0;
					}
					if crate::gaogaen::GAOGAEN_REVENGE_CURRENT_POWER_LEVEL[entry_id] == 1 {
						return 0.8;
					}
				}
				if param_hash == hash40("special_n_stick_accel_x") {
					if crate::gaogaen::GAOGAEN_REVENGE_CURRENT_POWER_LEVEL[entry_id] == 5 {
						return 0.1;
					}
					if crate::gaogaen::GAOGAEN_REVENGE_CURRENT_POWER_LEVEL[entry_id] == 4 {
						return 0.095;
					}
					if crate::gaogaen::GAOGAEN_REVENGE_CURRENT_POWER_LEVEL[entry_id] == 3 {
						return 0.09;
					}
					if crate::gaogaen::GAOGAEN_REVENGE_CURRENT_POWER_LEVEL[entry_id] == 2 {
						return 0.085;
					}
					if crate::gaogaen::GAOGAEN_REVENGE_CURRENT_POWER_LEVEL[entry_id] == 1 {
						return 0.08;
					}
				}
				if param_hash == hash40("special_air_n_speed_x_max") {
					if crate::gaogaen::GAOGAEN_REVENGE_CURRENT_POWER_LEVEL[entry_id] == 5 {
						return 1.6;
					}
					if crate::gaogaen::GAOGAEN_REVENGE_CURRENT_POWER_LEVEL[entry_id] == 4 {
						return 1.4;
					}
					if crate::gaogaen::GAOGAEN_REVENGE_CURRENT_POWER_LEVEL[entry_id] == 3 {
						return 1.2;
					}
					if crate::gaogaen::GAOGAEN_REVENGE_CURRENT_POWER_LEVEL[entry_id] == 2 {
						return 1.0;
					}
					if crate::gaogaen::GAOGAEN_REVENGE_CURRENT_POWER_LEVEL[entry_id] == 1 {
						return 0.8;
					}
				}
				if param_hash == hash40("special_air_n_stick_accel_x") {
					if crate::gaogaen::GAOGAEN_REVENGE_CURRENT_POWER_LEVEL[entry_id] == 5 {
						return 0.1;
					}
					if crate::gaogaen::GAOGAEN_REVENGE_CURRENT_POWER_LEVEL[entry_id] == 4 {
						return 0.095;
					}
					if crate::gaogaen::GAOGAEN_REVENGE_CURRENT_POWER_LEVEL[entry_id] == 3 {
						return 0.09;
					}
					if crate::gaogaen::GAOGAEN_REVENGE_CURRENT_POWER_LEVEL[entry_id] == 2 {
						return 0.085;
					}
					if crate::gaogaen::GAOGAEN_REVENGE_CURRENT_POWER_LEVEL[entry_id] == 1 {
						return 0.08;
					}
				}
			}
		}
		if fighter_kind == *FIGHTER_KIND_EDGE {
			if param_type == hash40("param_special_hi") {
				if param_hash == hash40("rush_speed") {
					if WorkModule::is_flag(boma, *FIGHTER_EDGE_INSTANCE_WORK_ID_FLAG_ONE_WINGED_ACTIVATED) {
						return 15.0;
					}
				}
				if param_hash == hash40("charged_rush_speed") {
					if WorkModule::is_flag(boma, *FIGHTER_EDGE_INSTANCE_WORK_ID_FLAG_ONE_WINGED_ACTIVATED) {
						return 7.7;
					}
				}
			}
			if param_type == hash40("param_special_lw") {
				if param_hash == hash40("shield_max") {
					if WorkModule::is_flag(boma, *FIGHTER_EDGE_INSTANCE_WORK_ID_FLAG_ONE_WINGED_ACTIVATED) {
						return 35.0;
					}
				}
			}
		}
		if fighter_kind == *FIGHTER_KIND_ELIGHT {
			if param_type == hash40("dash_speed") {
				if crate::elight::MYTHRA_UTHROW_SPEED[entry_id] {
					return 2.45;
				}
			}
			if param_type == hash40("run_speed_max") {
				if crate::elight::MYTHRA_UTHROW_SPEED[entry_id] {
					return 2.41;
				}
			}
			if param_type == hash40("run_accel_add") {
				if crate::elight::MYTHRA_UTHROW_SPEED[entry_id] {
					return 0.1;
				}
			}
			if param_type == hash40("air_speed_x_stable") {
				if crate::elight::MYTHRA_UTHROW_SPEED[entry_id] {
					return 1.3;
				}
			}
			if param_type == hash40("air_accel_x_mul") {
				if crate::elight::MYTHRA_UTHROW_SPEED[entry_id] {
					return 0.1;
				}
			}
			if param_type == hash40("air_accel_x_add") {
				if crate::elight::MYTHRA_UTHROW_SPEED[entry_id] {
					return 0.05;
				}
			}
		}
		if fighter_kind == *FIGHTER_KIND_TRAIL {
			if param_type == hash40("landing_attack_air_frame_lw") {
				if crate::trail::SORA_SLOW_DOWN_AIR[entry_id] {
					return 30.0;
				}
			}
		}
    }
	else if boma_reference.is_weapon() {
		let owner_module_accessor = &mut *sv_battle_object::module_accessor((WorkModule::get_int(boma, *WEAPON_INSTANCE_WORK_ID_INT_LINK_OWNER)) as u32);
		let entry_id = WorkModule::get_int(owner_module_accessor, *FIGHTER_INSTANCE_WORK_ID_INT_ENTRY_ID) as usize;
		if fighter_kind == *WEAPON_KIND_MARIO_FIREBALL {
			if param_type == hash40("param_fireball") {
				if param_hash == hash40("speed") {
					if crate::mario::MARIO_GIANT_FIREBALL[entry_id] {
						return 0.9;
					}
				}
				if param_hash == hash40("angle") {
					if crate::mario::MARIO_GIANT_FIREBALL[entry_id] {
						return 15.0;
					}
				}
				if param_hash == hash40("gravity_accel") {
					if crate::mario::MARIO_GIANT_FIREBALL[entry_id] {
						return 0.03;
					}
				}
				if param_hash == hash40("bounded_speed_y_min") {
					if crate::mario::MARIO_GIANT_FIREBALL[entry_id] {
						return 0.6;
					}
				}
				if param_hash == hash40("bounded_speed_y_max") {
					if crate::mario::MARIO_GIANT_FIREBALL[entry_id] {
						return 0.6;
					}
				}
			}
		}
		if fighter_kind == *WEAPON_KIND_MARIOD_DRCAPSULE {
			if param_type == hash40("param_drcapsule") {
				if param_hash == hash40("speed") {
					if crate::mariod::DR_SLOW_PILL[entry_id] {
					return 1.0;
					}
				}
			}
		}
		if fighter_kind == *WEAPON_KIND_MEWTWO_SHADOWBALL {
			if param_type == hash40("param_shadowball") {
				if param_hash == hash40("angle") {
					if crate::mewtwo::MEWTWO_NEUTRALB_DOWN_ANGLE[entry_id] {
						return -40.0;
					}
					if crate::mewtwo::MEWTWO_NEUTRALB_UP_ANGLE[entry_id] {
						return 40.0;
					}
				}
			}
		}
		if fighter_kind == *WEAPON_KIND_SZEROSUIT_PARALYZER_BULLET {
			if param_type == hash40("param_paralyzer_bullet") {
				if param_hash == hash40("speed_tame") {
					if crate::szerosuit::SZEROSUIT_LASER_TOGGLE_TYPE[entry_id] == 1 {
						return 2.8;
					}
					if crate::szerosuit::SZEROSUIT_LASER_TOGGLE_TYPE[entry_id] == 2 {
						return 2.0;
					}
				}
			}
		}
		if fighter_kind == *WEAPON_KIND_REFLET_GIGAFIRE {
			if param_type == hash40("param_gigafire") {
				if param_hash == hash40("shoot_angle") {
					if crate::reflet::REFLET_SIDEB_DOWN_ANGLE[entry_id] {
						return 50.0;
					}
					if crate::reflet::REFLET_SIDEB_UP_ANGLE[entry_id] {
						return -25.0;
					}
				}
			}
		}
		if fighter_kind == *WEAPON_KIND_PIKACHU_DENGEKIDAMA {
			if param_type == hash40("param_dengekidama") {
				if param_hash == hash40("angle_") {
					if crate::pikachu::PIKACHU_NEUTRALB_CHANGE_ANGLE[entry_id] {
						return -0.5;
					}
				}
			}
		}

		
	}
	
	original!()(module_accessor, param_type, param_hash)
}



//OG TR4SH Code
/*#[skyline::hook(offset=INT_OFFSET)] //used Lily's episode 26 and the old turbo mod code
pub unsafe fn get_param_int_replace(boma: u64, param_type: u64, param_hash: u64) -> i32 {
    let module_accessor = &mut *(*((boma as *mut u64).offset(1)) as *mut BattleObjectModuleAccessor);
    let fighter_kind = smash::app::utility::get_kind(module_accessor);
    let entry_id = WorkModule::get_int(module_accessor, *FIGHTER_INSTANCE_WORK_ID_INT_ENTRY_ID) as usize;
	
    if utility::get_category(module_accessor) == *BATTLE_OBJECT_CATEGORY_FIGHTER {
        /*if fighter_kind == *WEAPON_KIND_MARIO_FIREBALL {
            if param_type == hash40("param_fireball") {
                if param_hash == hash40("is_penetration") {
                    if crate::mario::MARIO_GIANT_FIREBALL[entry_id] {
                        return 1;
                    }
                }
            }
        }*/
    }
	if utility::get_category(module_accessor) == *BATTLE_OBJECT_CATEGORY_WEAPON {
        if fighter_kind == *WEAPON_KIND_MARIO_FIREBALL {
            if param_type == hash40("param_fireball") {
                if param_hash == hash40("is_penetration") {
                    if crate::mario::MARIO_GIANT_FIREBALL[entry_id] {
                        return 1;
                    }
                }
				if param_hash == hash40("life") {
					if crate::mario::MARIO_GIANT_FIREBALL[entry_id] {
						return 180;
					}
				}
            }
        }
		if fighter_kind == *WEAPON_KIND_SZEROSUIT_PARALYZER_BULLET {
			if param_type == hash40("param_paralyzer_bullet") {
				if param_hash == hash40("is_penetration") {
					if crate::szerosuit::SZEROSUIT_LASER_TOGGLE_TYPE[entry_id] == 1 {
						return 1;
					}
				}
			}
		}
    }

    original!()(boma, param_type, param_hash)
}*/

//Will'd version
#[skyline::hook(offset=INT_OFFSET)]
pub unsafe fn get_param_int_replace(module_accessor: u64, param_type: u64, param_hash :u64) -> i32 {
    let mut boma = *((module_accessor as *mut u64).offset(1)) as *mut BattleObjectModuleAccessor;
    let boma_reference = &mut *boma;
    let fighter_kind = boma_reference.kind();
    let entry_id = WorkModule::get_int(boma, *FIGHTER_INSTANCE_WORK_ID_INT_ENTRY_ID) as usize;
    if boma_reference.is_weapon() {

        // For articles
        let owner_module_accessor = &mut *sv_battle_object::module_accessor((WorkModule::get_int(boma, *WEAPON_INSTANCE_WORK_ID_INT_LINK_OWNER)) as u32);
		let entry_id = WorkModule::get_int(owner_module_accessor, *FIGHTER_INSTANCE_WORK_ID_INT_ENTRY_ID) as usize;
		
		if fighter_kind == *WEAPON_KIND_MARIO_FIREBALL {
            if param_type == hash40("param_fireball") {
                if param_hash == hash40("is_penetration") {
                    if crate::mario::MARIO_GIANT_FIREBALL[entry_id] {
                        return 1;
                    }
                }
				if param_hash == hash40("life") {
					if crate::mario::MARIO_GIANT_FIREBALL[entry_id] {
						return 180;
					}
				}
            }
        }
		if fighter_kind == *WEAPON_KIND_SZEROSUIT_PARALYZER_BULLET {
			if param_type == hash40("param_paralyzer_bullet") {
				if param_hash == hash40("is_penetration") {
					if crate::szerosuit::SZEROSUIT_LASER_TOGGLE_TYPE[entry_id] == 1 {
						return 1;
					}
				}
			}
		}
		if fighter_kind == *WEAPON_KIND_RYU_SHINKUHADOKEN {
			if param_type == hash40("param_shinkuhadoken") {
				if param_hash == hash40("life") {
					if crate::ryu::DAN_MODE[entry_id] {
                        return 25;
                    }
				}
				
			}
		}
		if fighter_kind == *WEAPON_KIND_RYU_HADOKEN {
			if param_type == hash40("param_hadoken") {
				if param_hash == hash40("life_w") {
					if crate::ryu::DAN_MODE[entry_id] {
                        return 20;
                    }
				}
				if param_hash == hash40("life_m") {
					if crate::ryu::DAN_MODE[entry_id] {
                        return 17;
                    }
				}
				if param_hash == hash40("life_s") {
					if crate::ryu::DAN_MODE[entry_id] {
                        return 13;
                    }
				}
				if param_hash == hash40("life_w_sp") {
					if crate::ryu::DAN_MODE[entry_id] {
                        return 19;
                    }
				}
				if param_hash == hash40("life_m_sp") {
					if crate::ryu::DAN_MODE[entry_id] {
                        return 15;
                    }
				}
				if param_hash == hash40("life_s_sp") {
					if crate::ryu::DAN_MODE[entry_id] {
                        return 11;
                    }
				}
			}
		}
		
	}
    original!()(module_accessor, param_type, param_hash)
}


//Installation
pub fn install() {
	unsafe {
        let text_ptr = getRegionAddress(Region::Text) as *const u8;
        let text_size = (getRegionAddress(Region::Rodata) as usize) - (text_ptr as usize);
        let text = std::slice::from_raw_parts(text_ptr, text_size);
        if let Some(offset) = find_subsequence(text, FLOAT_SEARCH_CODE) {
            FLOAT_OFFSET = offset;
        }
        if let Some(offset) = find_subsequence(text, INT_SEARCH_CODE) {
            INT_OFFSET = offset;
        }
    }
	skyline::install_hooks!(get_param_float_replace);
	skyline::install_hooks!(get_param_int_replace);
	skyline::install_hooks!(offset_dump);
}

