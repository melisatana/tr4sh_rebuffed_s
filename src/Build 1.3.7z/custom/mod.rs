use smash::hash40;
use smash::app::lua_bind::*;
use smash::lib::lua_const::*;
use smash::app::utility::get_kind;
use smash::lua2cpp::{L2CFighterCommon, L2CFighterBase};
use smashline::*;
use smash::app::*;

static DEBUG_ALLOW_MOMENTUM_JUMPS : bool = false;

//determines who cannot cancel jab1 into ftilt
unsafe fn can_jab1_cancel_to_ftilt(fighter: &mut L2CFighterCommon) -> bool {
    let fighter_kind = WorkModule::get_int(fighter.module_accessor, *FIGHTER_INSTANCE_WORK_ID_INT_KIND);
    if [*FIGHTER_KIND_DONKEY, *FIGHTER_KIND_TANTAN, *FIGHTER_KIND_RYU, *FIGHTER_KIND_KEN, *FIGHTER_KIND_DEMON, *FIGHTER_KIND_PALUTENA].contains(&fighter_kind) {
        return false;
    }
    return true;
}

//determines who cannot cancel jab1 into utilt
unsafe fn can_jab1_cancel_to_utilt(fighter: &mut L2CFighterCommon) -> bool {
    let fighter_kind = WorkModule::get_int(fighter.module_accessor, *FIGHTER_INSTANCE_WORK_ID_INT_KIND);
    if [*FIGHTER_KIND_RYU, *FIGHTER_KIND_KEN].contains(&fighter_kind) {
        return false;
    }
    return true;
}

//determines who cannot cancel jab1 into dtilt
unsafe fn can_jab1_cancel_to_dtilt(fighter: &mut L2CFighterCommon) -> bool {
    let fighter_kind = WorkModule::get_int(fighter.module_accessor, *FIGHTER_INSTANCE_WORK_ID_INT_KIND);
    if [*FIGHTER_KIND_KIRBY, *FIGHTER_KIND_DOLLY, *FIGHTER_KIND_PACMAN, *FIGHTER_KIND_ROBOT, *FIGHTER_KIND_TOONLINK, *FIGHTER_KIND_RYU, *FIGHTER_KIND_KEN].contains(&fighter_kind) {
        return false;
    }
    return true;
}


//determines who cannot cancel jab2 into ftilt
unsafe fn can_jab2_cancel_to_ftilt(fighter: &mut L2CFighterCommon) -> bool {
    let fighter_kind = WorkModule::get_int(fighter.module_accessor, *FIGHTER_INSTANCE_WORK_ID_INT_KIND);
    if [*FIGHTER_KIND_DONKEY, *FIGHTER_KIND_TANTAN, *FIGHTER_KIND_SAMUS, *FIGHTER_KIND_SAMUSD, *FIGHTER_KIND_YOSHI, *FIGHTER_KIND_POPO, *FIGHTER_KIND_NANA, *FIGHTER_KIND_PURIN, *FIGHTER_KIND_ROBOT, *FIGHTER_KIND_PEACH, *FIGHTER_KIND_DAISY, *FIGHTER_KIND_PIKMIN, *FIGHTER_KIND_WARIO, *FIGHTER_KIND_DEMON, *FIGHTER_KIND_KOOPA, *FIGHTER_KIND_LUCINA].contains(&fighter_kind) {
        return false;
    }
    return true;
}

//determines who cannot cancel jab2 into utilt
unsafe fn can_jab2_cancel_to_utilt(fighter: &mut L2CFighterCommon) -> bool {
    let fighter_kind = WorkModule::get_int(fighter.module_accessor, *FIGHTER_INSTANCE_WORK_ID_INT_KIND);
    if [*FIGHTER_KIND_SAMUS, *FIGHTER_KIND_SAMUSD, *FIGHTER_KIND_DONKEY, *FIGHTER_KIND_MARTH, *FIGHTER_KIND_LUCINA, *FIGHTER_KIND_YOSHI, *FIGHTER_KIND_POPO, *FIGHTER_KIND_NANA, *FIGHTER_KIND_PURIN, *FIGHTER_KIND_ROBOT, *FIGHTER_KIND_PEACH, *FIGHTER_KIND_DAISY, *FIGHTER_KIND_PIKMIN, *FIGHTER_KIND_WARIO, *FIGHTER_KIND_RYU, *FIGHTER_KIND_KEN, *FIGHTER_KIND_KOOPA, *FIGHTER_KIND_LUCINA].contains(&fighter_kind) {
        return false;
    }
    return true;
}

//determines who cannot cancel jab2 into dtilt
unsafe fn can_jab2_cancel_to_dtilt(fighter: &mut L2CFighterCommon) -> bool {
    let fighter_kind = WorkModule::get_int(fighter.module_accessor, *FIGHTER_INSTANCE_WORK_ID_INT_KIND);
    if [*FIGHTER_KIND_KIRBY, *FIGHTER_KIND_DONKEY, *FIGHTER_KIND_DOLLY, *FIGHTER_KIND_PACMAN, *FIGHTER_KIND_ROBOT, *FIGHTER_KIND_TOONLINK, *FIGHTER_KIND_SAMUS, *FIGHTER_KIND_SAMUSD, *FIGHTER_KIND_MARTH, *FIGHTER_KIND_LUCINA, *FIGHTER_KIND_POPO, *FIGHTER_KIND_NANA, *FIGHTER_KIND_PURIN, *FIGHTER_KIND_PEACH, *FIGHTER_KIND_DAISY, *FIGHTER_KIND_PIKMIN, *FIGHTER_KIND_WARIO, *FIGHTER_KIND_RYU, *FIGHTER_KIND_KEN, *FIGHTER_KIND_KOOPA, *FIGHTER_KIND_LUCINA].contains(&fighter_kind) {
        return false;
    }
    return true;
}

// Use this for general per-frame fighter-level hooks
#[fighter_frame_callback]
pub fn global_fighter_frame(fighter : &mut L2CFighterCommon) {
    unsafe {
        let module_accessor = smash::app::sv_system::battle_object_module_accessor(fighter.lua_state_agent);
        let status = StatusModule::status_kind(fighter.module_accessor);
        let mut stickx = ControlModule::get_stick_x(module_accessor);
        let lr = PostureModule::lr(module_accessor);
        stickx = stickx * lr;
        
        if StatusModule::is_situation_changed(module_accessor) {
            let situation_kind = &format!("{}", StatusModule::situation_kind(module_accessor));
            println!(
                "[Fighter Hook]\nFighter Kind: {}\nStatus Kind: {}\nSituation Kind: {}",
                get_kind(module_accessor),
                StatusModule::status_kind(module_accessor),
                match StatusModule::situation_kind(module_accessor) {
                    0 => "SITUATION_KIND_GROUND",
                    1 => "SITUATION_KIND_CLIFF",
                    2 => "SITUATION_KIND_AIR",
                    _ => situation_kind
                }
            );
        }

        //momentum jumps (currently disabled)
        if DEBUG_ALLOW_MOMENTUM_JUMPS && WorkModule::is_flag(module_accessor, *FIGHTER_INSTANCE_WORK_ID_FLAG_JUMP_NO_LIMIT) == false {
            WorkModule::on_flag(module_accessor, *FIGHTER_INSTANCE_WORK_ID_FLAG_JUMP_NO_LIMIT);
        };

        if MotionModule::motion_kind(module_accessor) == hash40("dash") && MotionModule::frame(module_accessor) <= (40.0) {
            if stickx < -0.5 {
                StatusModule::change_status_request_from_script(module_accessor, *FIGHTER_STATUS_KIND_TURN, true);
                println!("Perfect pivot lets go!");
            };
        };

        //this disables jostle on pivot grabs
        if [*FIGHTER_STATUS_KIND_CATCH_TURN].contains(&status) {
            JostleModule::set_status(fighter.module_accessor, false);
        }
        
        //this was meant to be a way to implement DACUS
        /*if [*FIGHTER_STATUS_KIND_ATTACK_DASH].contains(&status) {
            //if MotionModule::frame(fighter.module_accessor) <= 5.0 {
                //peepee poopoo
            }
        }*/

        //cancel Jab1 with Ftilt
        if MotionModule::motion_kind(fighter.module_accessor) == hash40("attack_11") {
            if can_jab1_cancel_to_ftilt(fighter) && AttackModule::is_infliction_status(fighter.module_accessor, *COLLISION_KIND_MASK_HIT) && AttackModule::is_infliction(fighter.module_accessor, *COLLISION_KIND_MASK_HIT) == false {
                WorkModule::enable_transition_term(fighter.module_accessor, *FIGHTER_STATUS_TRANSITION_TERM_ID_CONT_ATTACK_S3);
                fighter.sub_transition_group_check_ground_attack();
            }
        }

        //cancel Jab1 with Utilt
        if MotionModule::motion_kind(fighter.module_accessor) == hash40("attack_11") {
            if can_jab1_cancel_to_utilt(fighter) && AttackModule::is_infliction_status(fighter.module_accessor, *COLLISION_KIND_MASK_HIT) && AttackModule::is_infliction(fighter.module_accessor, *COLLISION_KIND_MASK_HIT) == false {
                WorkModule::enable_transition_term(fighter.module_accessor, *FIGHTER_STATUS_TRANSITION_TERM_ID_CONT_ATTACK_HI3);
                fighter.sub_transition_group_check_ground_attack();
            }
        }

        //cancel Jab1 with Dtilt
        if MotionModule::motion_kind(fighter.module_accessor) == hash40("attack_11") {
            if can_jab1_cancel_to_dtilt(fighter) && AttackModule::is_infliction_status(fighter.module_accessor, *COLLISION_KIND_MASK_HIT) && AttackModule::is_infliction(fighter.module_accessor, *COLLISION_KIND_MASK_HIT) == false {
                WorkModule::enable_transition_term(fighter.module_accessor, *FIGHTER_STATUS_TRANSITION_TERM_ID_CONT_ATTACK_LW3);
                fighter.sub_transition_group_check_ground_attack();
            }
        }

        //cancel Jab1 with Ftilt
        if MotionModule::motion_kind(fighter.module_accessor) == hash40("attack_12") {
            if can_jab2_cancel_to_ftilt(fighter) && AttackModule::is_infliction_status(fighter.module_accessor, *COLLISION_KIND_MASK_HIT) && AttackModule::is_infliction(fighter.module_accessor, *COLLISION_KIND_MASK_HIT) == false {
                WorkModule::enable_transition_term(fighter.module_accessor, *FIGHTER_STATUS_TRANSITION_TERM_ID_CONT_ATTACK_S3);
                fighter.sub_transition_group_check_ground_attack();
            }
        }

        //cancel Jab1 with Utilt
        if MotionModule::motion_kind(fighter.module_accessor) == hash40("attack_12") {
            if can_jab2_cancel_to_utilt(fighter) && AttackModule::is_infliction_status(fighter.module_accessor, *COLLISION_KIND_MASK_HIT) && AttackModule::is_infliction(fighter.module_accessor, *COLLISION_KIND_MASK_HIT) == false {
                WorkModule::enable_transition_term(fighter.module_accessor, *FIGHTER_STATUS_TRANSITION_TERM_ID_CONT_ATTACK_HI3);
                fighter.sub_transition_group_check_ground_attack();
            }
        }

        //cancel Jab2 with Dtilt
        if MotionModule::motion_kind(fighter.module_accessor) == hash40("attack_12") {
            if can_jab2_cancel_to_dtilt(fighter) && AttackModule::is_infliction_status(fighter.module_accessor, *COLLISION_KIND_MASK_HIT) && AttackModule::is_infliction(fighter.module_accessor, *COLLISION_KIND_MASK_HIT) == false {
                WorkModule::enable_transition_term(fighter.module_accessor, *FIGHTER_STATUS_TRANSITION_TERM_ID_CONT_ATTACK_LW3);
                fighter.sub_transition_group_check_ground_attack();
            }
        }
        
        //global ledge cancelling on aerials and light/heavy landing and taunts 
        if [*FIGHTER_STATUS_KIND_LANDING_ATTACK_AIR, *FIGHTER_STATUS_KIND_LANDING, *FIGHTER_STATUS_KIND_LANDING_LIGHT, *FIGHTER_STATUS_KIND_APPEAL].contains(&status) {
            GroundModule::correct(fighter.module_accessor, GroundCorrectKind(*GROUND_CORRECT_KIND_GROUND));
        }


    }

}


// Use this for general per-frame weapon-level hooks
#[weapon_frame_callback]
pub fn global_weapon_frame(fighter_base : &mut L2CFighterBase) {
    unsafe {
        let module_accessor = smash::app::sv_system::battle_object_module_accessor(fighter_base.lua_state_agent);
        let frame = smash::app::lua_bind::MotionModule::frame(module_accessor) as i32;

        if frame % 10 == 0 {
            println!("[Weapon Hook] Frame : {}", frame);
        }
    }
}

pub fn install() {
    smashline::install_agent_frame_callbacks!(
        global_fighter_frame,
        global_weapon_frame
    );
}